package main

import (
	"context"
	"flag"
	"fmt"
	"log"
	"os"
	"runtime"
	"time"

	"github.com/example/baltimore-civic-insights/internal/civic"
)

func main() {
	defaultWorkers := runtime.NumCPU()
	if defaultWorkers > 8 {
		defaultWorkers = 8
	}
	if defaultWorkers < 1 {
		defaultWorkers = 1
	}
	offline := flag.Bool("offline", false, "use included synthetic fixtures rather than live ArcGIS endpoints")
	limit := flag.Int("limit", 50000, "maximum records per dataset; 0 means no cap")
	workers := flag.Int("workers", defaultWorkers, "concurrent worker count")
	outDir := flag.String("out", "output", "directory to write raw data, CSVs, and report")
	timeout := flag.Duration("timeout", 45*time.Second, "HTTP request timeout for live ingestion")
	fixturesDir := flag.String("fixtures", "fixtures", "fixture directory used with --offline")
	flag.Parse()

	if *workers < 1 {
		log.Fatal("--workers must be at least 1")
	}
	if *limit < 0 {
		log.Fatal("--limit cannot be negative")
	}

	cfg := civic.Config{
		Offline:     *offline,
		Limit:       *limit,
		Workers:     *workers,
		OutDir:      *outDir,
		FixturesDir: *fixturesDir,
		Timeout:     *timeout,
	}
	if err := civic.Run(context.Background(), cfg, os.Stdout); err != nil {
		fmt.Fprintln(os.Stderr, "baltimore-insights:", err)
		os.Exit(1)
	}
}
