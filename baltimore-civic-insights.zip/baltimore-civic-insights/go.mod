module github.com/example/baltimore-civic-insights

go 1.22
