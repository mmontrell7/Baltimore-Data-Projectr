package civic

import (
	"encoding/csv"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"time"
)

func writeCSVFile(path string, header []string, rows [][]string) error {
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		return err
	}
	file, err := os.Create(path)
	if err != nil {
		return err
	}
	defer file.Close()
	writer := csv.NewWriter(file)
	if err := writer.Write(header); err != nil {
		return err
	}
	for _, row := range rows {
		if err := writer.Write(row); err != nil {
			return err
		}
	}
	writer.Flush()
	return writer.Error()
}

func writeOutputs(dir string, report Report) error {
	neighborhoodRows := make([][]string, 0, len(report.Neighborhoods))
	for _, r := range report.Neighborhoods {
		neighborhoodRows = append(neighborhoodRows, []string{r.Neighborhood, strconv.Itoa(r.Requests), strconv.Itoa(r.Closed), fmt.Sprintf("%.2f", r.CloseRate), fmt.Sprintf("%.2f", r.AvgCloseDays), strconv.Itoa(r.RehabSites)})
	}
	if err := writeCSVFile(filepath.Join(dir, "neighborhood_summary.csv"), []string{"neighborhood", "requests_311", "closed_or_resolved", "closed_rate_percent", "avg_close_days_with_valid_dates", "recorded_rehab_locations"}, neighborhoodRows); err != nil {
		return err
	}

	districtRows := make([][]string, 0, len(report.Districts))
	for _, r := range report.Districts {
		districtRows = append(districtRows, []string{r.CouncilDistrict, strconv.Itoa(r.Requests), strconv.Itoa(r.Closed), fmt.Sprintf("%.2f", r.CloseRate), fmt.Sprintf("%.2f", r.AvgCloseDays), strconv.Itoa(r.RehabSites), fmt.Sprintf("%.2f", r.RehabsPer1000Requests)})
	}
	if err := writeCSVFile(filepath.Join(dir, "council_district_summary.csv"), []string{"council_district", "requests_311", "closed_or_resolved", "closed_rate_percent", "avg_close_days_with_valid_dates", "recorded_rehab_locations", "rehabs_per_1000_requests"}, districtRows); err != nil {
		return err
	}

	typeRows := make([][]string, 0, len(report.Types))
	for _, r := range report.Types {
		typeRows = append(typeRows, []string{r.RequestType, strconv.Itoa(r.Count), fmt.Sprintf("%.2f", r.Share)})
	}
	if err := writeCSVFile(filepath.Join(dir, "top_request_types.csv"), []string{"request_type", "count", "share_percent"}, typeRows); err != nil {
		return err
	}

	if err := writeReport(filepath.Join(dir, "summary.md"), report); err != nil {
		return err
	}
	metadata := struct {
		GeneratedAt    string `json:"generated_at_utc"`
		Offline        bool   `json:"offline_fixture_mode"`
		Workers        int    `json:"workers"`
		Limit          int    `json:"record_limit_per_dataset"`
		RequestRecords int    `json:"requests_311_loaded"`
		RehabRecords   int    `json:"rehab_records_loaded"`
		RequestSource  string `json:"311_source_url"`
		RehabSource    string `json:"rehab_source_url"`
	}{report.GeneratedAt.Format(time.RFC3339), report.Offline, report.Workers, report.Limit, report.RequestCount, report.RehabCount, report.RequestSource, report.RehabSource}
	file, err := os.Create(filepath.Join(dir, "run_metadata.json"))
	if err != nil {
		return err
	}
	enc := json.NewEncoder(file)
	enc.SetIndent("", "  ")
	if err := enc.Encode(metadata); err != nil {
		file.Close()
		return err
	}
	return file.Close()
}

func writeReport(path string, report Report) error {
	file, err := os.Create(path)
	if err != nil {
		return err
	}
	defer file.Close()
	_, err = io.WriteString(file, renderReport(report))
	return err
}

func renderReport(r Report) string {
	var b strings.Builder
	mode := "live Open Baltimore API data"
	if r.Offline {
		mode = "synthetic offline fixture data (not real city statistics)"
	}
	fmt.Fprintf(&b, "# Baltimore Civic Insights\n\nGenerated: %s\n\nData mode: **%s**\n\n", r.GeneratedAt.Format(time.RFC3339), mode)
	fmt.Fprintf(&b, "## Coverage and limitations\n\n- 311 records analyzed: **%d**\n- Vacant-building rehab records analyzed: **%d**\n- Records marked closed/resolved/completed (or with a close date): **%d of %d (%.1f%%)**\n- Average close duration among records with valid creation and close dates: **%.2f days**\n- Worker count: **%d**; per-dataset record cap: **%s**\n\n", r.RequestCount, r.RehabCount, r.ClosedCount, r.RequestCount, r.OverallCloseRate, r.AvgCloseDays, r.Workers, limitLabel(r.Limit))
	b.WriteString("The 311 layer is for the current calendar year and is described by its publisher as updated daily. The Vacant Building Rehabs layer records rehabilitation locations and has an older published data-edit timestamp (June 30, 2023). These sources are not equally current. Rehabilitation-location counts are not a count of all vacant buildings, and cross-dataset co-occurrence is descriptive rather than evidence of causation. Blank/missing neighborhood and district labels are excluded from those geographic joins but remain in citywide totals.\n\n")
	fmt.Fprintf(&b, "Sources: [311 Customer Service Requests 2026](%s) · [Vacant Building Rehabs](%s) · [Open Baltimore portal](https://data.baltimorecity.gov/)\n\n", r.RequestSource, r.RehabSource)

	b.WriteString("## Research question 1 — Which neighborhoods have the highest 311 workload?\n\n")
	b.WriteString("Top neighborhoods by request count (current snapshot / records loaded).\n\n")
	b.WriteString("| Neighborhood | 311 requests | Rehab locations recorded | Closed rate |\n|---|---:|---:|---:|\n")
	for _, row := range takeNeighborhoods(r.Neighborhoods, 10) {
		fmt.Fprintf(&b, "| %s | %d | %d | %.1f%% |\n", escapeCell(row.Neighborhood), row.Requests, row.RehabSites, row.CloseRate)
	}
	b.WriteString("\n```text\n" + chartNeighborhoods(r.Neighborhoods, 8) + "```\n\n")

	b.WriteString("## Research question 2 — Which request types dominate service demand?\n\n")
	b.WriteString("| Request type | Count | Share of loaded requests |\n|---|---:|---:|\n")
	for i, row := range takeTypes(r.Types, 10) {
		fmt.Fprintf(&b, "| %s | %d | %.1f%% |\n", escapeCell(row.RequestType), row.Count, row.Share)
		if i == 9 {
			break
		}
	}
	b.WriteString("\n```text\n" + chartTypes(r.Types, 8) + "```\n\n")

	b.WriteString("## Research question 3 — Which neighborhoods combine many 311 requests with recorded rehabilitation activity?\n\n")
	b.WriteString("This is a joined descriptive view, not a risk score. The join key is a normalized neighborhood name (case and punctuation standardized). Rankings below are ordered by 311 request volume; the rehab count is shown alongside each count.\n\n")
	b.WriteString("| Neighborhood | 311 requests | Rehab locations recorded |\n|---|---:|---:|\n")
	for _, row := range takeJointNeighborhoods(r.Neighborhoods, 10) {
		fmt.Fprintf(&b, "| %s | %d | %d |\n", escapeCell(row.Neighborhood), row.Requests, row.RehabSites)
	}
	b.WriteString("\n")

	b.WriteString("## Research question 4 — How does recorded rehabilitation activity compare with 311 volume by council district?\n\n")
	b.WriteString("The ratio is recorded rehab locations per 1,000 loaded 311 requests. Low request counts can make this ratio volatile; it should be reviewed alongside the underlying counts.\n\n")
	b.WriteString("| Council district | 311 requests | Rehab locations recorded | Rehabs / 1,000 requests |\n|---|---:|---:|---:|\n")
	districtsByRatio := append([]DistrictRow(nil), r.Districts...)
	sort.Slice(districtsByRatio, func(i, j int) bool {
		if (districtsByRatio[i].Requests > 0) != (districtsByRatio[j].Requests > 0) {
			return districtsByRatio[i].Requests > 0
		}
		if districtsByRatio[i].RehabsPer1000Requests != districtsByRatio[j].RehabsPer1000Requests {
			return districtsByRatio[i].RehabsPer1000Requests > districtsByRatio[j].RehabsPer1000Requests
		}
		return districtLess(districtsByRatio[i].CouncilDistrict, districtsByRatio[j].CouncilDistrict)
	})
	for _, row := range districtsByRatio {
		fmt.Fprintf(&b, "| %s | %d | %d | %s |\n", escapeCell(row.CouncilDistrict), row.Requests, row.RehabSites, ratioLabel(row))
	}
	b.WriteString("\n```text\n" + chartDistrictRehab(districtsByRatio, 10) + "```\n\n")

	b.WriteString("## Research question 5 — How do closure outcomes and times vary by council district?\n\n")
	b.WriteString("Closure rate is the share with a close date or a status containing closed, resolved, or completed. Average close time uses only records with valid creation and close dates and non-negative duration. A zero in the duration column means no valid duration was available, not instantaneous closure.\n\n")
	b.WriteString("| Council district | Requests | Closed / resolved | Closed rate | Avg. close days (valid dates) |\n|---|---:|---:|---:|---:|\n")
	for _, row := range r.Districts {
		fmt.Fprintf(&b, "| %s | %d | %d | %.1f%% | %.2f |\n", escapeCell(row.CouncilDistrict), row.Requests, row.Closed, row.CloseRate, row.AvgCloseDays)
	}
	b.WriteString("\n## Reproducibility\n\nRaw input snapshots are in `raw/`. CSV files are machine-readable companion outputs. If running in offline mode, fixtures are synthetic and must not be reported as observed Baltimore data.\n")
	return b.String()
}

func ratioLabel(row DistrictRow) string {
	if row.Requests == 0 {
		return "N/A"
	}
	return fmt.Sprintf("%.2f", row.RehabsPer1000Requests)
}

func limitLabel(n int) string {
	if n == 0 {
		return "unbounded (0)"
	}
	return strconv.Itoa(n)
}
func escapeCell(s string) string {
	return strings.ReplaceAll(strings.ReplaceAll(s, "|", "\\|"), "\n", " ")
}
func takeNeighborhoods(rows []NeighborhoodRow, count int) []NeighborhoodRow {
	filtered := make([]NeighborhoodRow, 0, len(rows))
	for _, row := range rows {
		if row.Requests > 0 {
			filtered = append(filtered, row)
		}
	}
	if len(filtered) < count {
		count = len(filtered)
	}
	return filtered[:count]
}
func takeJointNeighborhoods(rows []NeighborhoodRow, count int) []NeighborhoodRow {
	joined := make([]NeighborhoodRow, 0, len(rows))
	for _, row := range rows {
		if row.Requests > 0 && row.RehabSites > 0 {
			joined = append(joined, row)
		}
	}
	sort.Slice(joined, func(i, j int) bool {
		if joined[i].Requests != joined[j].Requests {
			return joined[i].Requests > joined[j].Requests
		}
		if joined[i].RehabSites != joined[j].RehabSites {
			return joined[i].RehabSites > joined[j].RehabSites
		}
		return joined[i].Neighborhood < joined[j].Neighborhood
	})
	if len(joined) < count {
		count = len(joined)
	}
	return joined[:count]
}

func takeTypes(rows []TypeRow, count int) []TypeRow {
	if len(rows) < count {
		count = len(rows)
	}
	return rows[:count]
}

func bar(value, maxValue, width int) string {
	if maxValue <= 0 || value <= 0 || width <= 0 {
		return ""
	}
	count := value * width / maxValue
	if count < 1 {
		count = 1
	}
	return strings.Repeat("#", count)
}

func chartNeighborhoods(rows []NeighborhoodRow, maxRows int) string {
	rows = takeNeighborhoods(rows, maxRows)
	maxValue := 0
	for _, r := range rows {
		if r.Requests > maxValue {
			maxValue = r.Requests
		}
	}
	var b strings.Builder
	for _, r := range rows {
		fmt.Fprintf(&b, "%-24s %6d %s\n", truncate(r.Neighborhood, 24), r.Requests, bar(r.Requests, maxValue, 24))
	}
	if len(rows) == 0 {
		b.WriteString("(No neighborhood records with a usable name.)\n")
	}
	return b.String()
}

func chartTypes(rows []TypeRow, maxRows int) string {
	rows = takeTypes(rows, maxRows)
	maxValue := 0
	for _, r := range rows {
		if r.Count > maxValue {
			maxValue = r.Count
		}
	}
	var b strings.Builder
	for _, r := range rows {
		fmt.Fprintf(&b, "%-24s %6d %s\n", truncate(r.RequestType, 24), r.Count, bar(r.Count, maxValue, 24))
	}
	if len(rows) == 0 {
		b.WriteString("(No request type records.)\n")
	}
	return b.String()
}

func chartDistrictRehab(rows []DistrictRow, maxRows int) string {
	if len(rows) > maxRows {
		rows = rows[:maxRows]
	}
	maxValue := 0
	for _, r := range rows {
		if r.RehabSites > maxValue {
			maxValue = r.RehabSites
		}
	}
	var b strings.Builder
	for _, r := range rows {
		fmt.Fprintf(&b, "District %-4s %5d %s\n", r.CouncilDistrict, r.RehabSites, bar(r.RehabSites, maxValue, 24))
	}
	if len(rows) == 0 {
		b.WriteString("(No district records with a usable name.)\n")
	}
	return b.String()
}

func truncate(s string, max int) string {
	runes := []rune(s)
	if len(runes) <= max {
		return s
	}
	if max <= 1 {
		return string(runes[:max])
	}
	return string(runes[:max-1]) + "…"
}

func printTerminal(w io.Writer, r Report) {
	fmt.Fprintf(w, "\nBaltimore Civic Insights\n========================\nMode: %s | 311: %d | rehab locations: %d | workers: %d\n", modeLabel(r.Offline), r.RequestCount, r.RehabCount, r.Workers)
	fmt.Fprintf(w, "Overall closed/resolved share: %.1f%%; average close time for valid dates: %.2f days\n\n", r.OverallCloseRate, r.AvgCloseDays)
	fmt.Fprintln(w, "Top neighborhoods by 311 requests:")
	fmt.Fprintln(w, chartNeighborhoods(r.Neighborhoods, 8))
	fmt.Fprintln(w, "Top request types:")
	fmt.Fprintln(w, chartTypes(r.Types, 8))
	fmt.Fprintf(w, "\nReports and raw snapshots written to: %s\n\n", filepath.Clean("output"))
}

func modeLabel(offline bool) string {
	if offline {
		return "synthetic offline fixture"
	}
	return "live API"
}
