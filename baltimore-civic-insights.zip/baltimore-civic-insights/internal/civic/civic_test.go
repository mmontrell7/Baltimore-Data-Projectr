package civic

import (
	"bytes"
	"context"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestNormalizeKey(t *testing.T) {
	if got, want := normalizeKey(" Pigtown/Washington Village "), "pigtown washington village"; got != want {
		t.Fatalf("normalizeKey() = %q, want %q", got, want)
	}
	if got := normalizeKey(" "); got != "" {
		t.Fatalf("blank key should normalize to empty, got %q", got)
	}
	if got := normalizeDistrictKey("Council District 07"); got != "7" {
		t.Fatalf("normalizeDistrictKey() = %q, want \"7\"", got)
	}
}

func TestDateValueAndClosedStatus(t *testing.T) {
	want := time.Date(2026, time.January, 2, 10, 0, 0, 0, time.UTC)
	got := dateValue(float64(want.UnixMilli()))
	if !got.Equal(want) {
		t.Fatalf("dateValue() = %v, want %v", got, want)
	}
	if !closedStatus("Resolved", time.Time{}) {
		t.Fatal("Resolved status should count as closed")
	}
	if closedStatus("In Progress", time.Time{}) {
		t.Fatal("In Progress should not count as closed")
	}
}

func TestParseAndJoin(t *testing.T) {
	cfg := Config{Workers: 3}
	sources := sourceCatalog()
	requestFS, err := (OfflineLoader{}).Load(context.Background(), sources[0], Config{FixturesDir: "../../fixtures"})
	if err != nil {
		t.Fatal(err)
	}
	rehabFS, err := (OfflineLoader{}).Load(context.Background(), sources[1], Config{FixturesDir: "../../fixtures"})
	if err != nil {
		t.Fatal(err)
	}
	requests := parseRequests(requestFS.Features, cfg.Workers)
	rehabs := parseRehabs(rehabFS.Features, cfg.Workers)
	if len(requests) != 12 {
		t.Fatalf("parsed %d requests, want 12", len(requests))
	}
	if len(rehabs) != 10 {
		t.Fatalf("parsed %d rehab records, want 10", len(rehabs))
	}
	report := buildReport(requests, rehabs, cfg, sources)
	if report.RequestCount != 12 || report.RehabCount != 10 {
		t.Fatalf("unexpected totals: 311=%d rehab=%d", report.RequestCount, report.RehabCount)
	}
	if report.ClosedCount != 9 {
		t.Fatalf("closed count = %d, want 9", report.ClosedCount)
	}
	if report.OverallCloseRate < 74.9 || report.OverallCloseRate > 75.1 {
		t.Fatalf("close rate = %.2f, want about 75%%", report.OverallCloseRate)
	}
	foundDowntown := false
	for _, row := range report.Neighborhoods {
		if row.Neighborhood == "Downtown" {
			foundDowntown = true
			if row.Requests != 3 || row.RehabSites != 2 {
				t.Fatalf("Downtown join = requests %d, rehabs %d; want 3 and 2", row.Requests, row.RehabSites)
			}
		}
	}
	if !foundDowntown {
		t.Fatal("joined report should contain Downtown")
	}
	if len(report.Types) == 0 || report.Types[0].RequestType != "Illegal Dumping" {
		t.Fatalf("top type = %#v, want Illegal Dumping", report.Types)
	}
}

func TestOfflineRunProducesArtifacts(t *testing.T) {
	out := t.TempDir()
	var stdout bytes.Buffer
	err := Run(context.Background(), Config{
		Offline: true, Limit: 50000, Workers: 3, OutDir: out,
		FixturesDir: "../../fixtures", Timeout: 5 * time.Second,
	}, &stdout)
	if err != nil {
		t.Fatalf("offline Run() error: %v\nstdout: %s", err, stdout.String())
	}
	for _, rel := range []string{
		"raw/311_requests.json", "raw/vacant_building_rehabs.json",
		"neighborhood_summary.csv", "council_district_summary.csv",
		"top_request_types.csv", "summary.md", "run_metadata.json",
	} {
		if info, err := os.Stat(filepath.Join(out, rel)); err != nil || info.Size() == 0 {
			t.Fatalf("expected nonempty output %s (stat=%v, err=%v)", rel, info, err)
		}
	}
	summary, err := os.ReadFile(filepath.Join(out, "summary.md"))
	if err != nil {
		t.Fatal(err)
	}
	for _, heading := range []string{
		"Research question 1", "Research question 2", "Research question 3",
		"Research question 4", "Research question 5", "synthetic offline fixture data",
	} {
		if !strings.Contains(string(summary), heading) {
			t.Errorf("summary.md missing %q", heading)
		}
	}
	if !strings.Contains(stdout.String(), "Top neighborhood chart") || !strings.Contains(stdout.String(), "#") {
		t.Errorf("terminal output should include an ASCII chart; got:\n%s", stdout.String())
	}
}
