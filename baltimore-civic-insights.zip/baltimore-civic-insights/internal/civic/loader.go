package civic

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"
)

type Loader interface {
	Load(context.Context, Source, Config) (FeatureSet, error)
}

type OfflineLoader struct{}
type ArcGISLoader struct{ client *http.Client }

// NewLoader is the factory for the two ingestion strategies.
func NewLoader(cfg Config) Loader {
	if cfg.Offline {
		return OfflineLoader{}
	}
	return ArcGISLoader{client: &http.Client{Timeout: cfg.Timeout}}
}

func (OfflineLoader) Load(_ context.Context, source Source, cfg Config) (FeatureSet, error) {
	path := filepath.Join(cfg.FixturesDir, source.Fixture)
	file, err := os.Open(path)
	if err != nil {
		return FeatureSet{}, fmt.Errorf("open fixture %s: %w", path, err)
	}
	defer file.Close()
	var fs FeatureSet
	decoder := json.NewDecoder(file)
	if err := decoder.Decode(&fs); err != nil {
		return FeatureSet{}, fmt.Errorf("decode fixture %s: %w", path, err)
	}
	if cfg.Limit > 0 && len(fs.Features) > cfg.Limit {
		fs.Features = fs.Features[:cfg.Limit]
	}
	return fs, nil
}

type arcGISIDResponse struct {
	ObjectIDs []int64      `json:"objectIds"`
	Error     *arcGISError `json:"error"`
}
type arcGISError struct {
	Code    int      `json:"code"`
	Message string   `json:"message"`
	Details []string `json:"details"`
}
type arcGISFeatureResponse struct {
	Features []Feature    `json:"features"`
	Error    *arcGISError `json:"error"`
}
type chunkJob struct {
	index int
	ids   []int64
}
type chunkResult struct {
	index    int
	features []Feature
	err      error
}

func (l ArcGISLoader) Load(ctx context.Context, source Source, cfg Config) (FeatureSet, error) {
	ids, err := l.fetchIDs(ctx, source)
	if err != nil {
		return FeatureSet{}, err
	}
	sort.Slice(ids, func(i, j int) bool { return ids[i] > ids[j] })
	if cfg.Limit > 0 && len(ids) > cfg.Limit {
		ids = ids[:cfg.Limit]
	}
	// The highest object IDs are typically recent inserts, although ArcGIS does
	// not guarantee OID chronology. Sorting is repeated after retrieval for
	// deterministic raw snapshots and analysis.
	const batchSize = 500
	chunks := make([][]int64, 0, (len(ids)+batchSize-1)/batchSize)
	for start := 0; start < len(ids); start += batchSize {
		end := start + batchSize
		if end > len(ids) {
			end = len(ids)
		}
		chunks = append(chunks, ids[start:end])
	}
	results := make([][]Feature, len(chunks))
	jobs := make(chan chunkJob)
	resultCh := make(chan chunkResult, len(chunks))
	workerCount := cfg.Workers
	if workerCount > len(chunks) {
		workerCount = len(chunks)
	}
	if workerCount < 1 {
		return FeatureSet{Features: []Feature{}}, nil
	}
	var wg sync.WaitGroup
	for w := 0; w < workerCount; w++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for job := range jobs {
				if err := ctx.Err(); err != nil {
					resultCh <- chunkResult{index: job.index, err: err}
					continue
				}
				features, err := l.fetchChunk(ctx, source, job.ids)
				resultCh <- chunkResult{index: job.index, features: features, err: err}
			}
		}()
	}
	go func() {
		defer close(jobs)
		for i, chunk := range chunks {
			select {
			case jobs <- chunkJob{index: i, ids: chunk}:
			case <-ctx.Done():
				return
			}
		}
	}()
	go func() { wg.Wait(); close(resultCh) }()
	var errs []error
	for result := range resultCh {
		if result.err != nil {
			errs = append(errs, fmt.Errorf("fetch %s batch %d: %w", source.Name, result.index+1, result.err))
			continue
		}
		results[result.index] = result.features
	}
	if len(errs) > 0 {
		return FeatureSet{}, errors.Join(errs...)
	}
	features := make([]Feature, 0, len(ids))
	for _, batch := range results {
		features = append(features, batch...)
	}
	sort.SliceStable(features, func(i, j int) bool {
		return toInt64(features[i].Attributes[source.OIDField]) < toInt64(features[j].Attributes[source.OIDField])
	})
	return FeatureSet{Features: features}, nil
}

func (l ArcGISLoader) fetchIDs(ctx context.Context, source Source) ([]int64, error) {
	u, _ := url.Parse(source.URL + "/query")
	q := u.Query()
	q.Set("where", "1=1")
	q.Set("returnIdsOnly", "true")
	q.Set("returnGeometry", "false")
	q.Set("f", "json")
	u.RawQuery = q.Encode()
	var payload arcGISIDResponse
	if err := l.getJSON(ctx, u.String(), &payload); err != nil {
		return nil, fmt.Errorf("list object IDs for %s: %w", source.Name, err)
	}
	if payload.Error != nil {
		return nil, payload.Error.asError()
	}
	return payload.ObjectIDs, nil
}

func (l ArcGISLoader) fetchChunk(ctx context.Context, source Source, ids []int64) ([]Feature, error) {
	idStrings := make([]string, len(ids))
	for i, id := range ids {
		idStrings[i] = strconv.FormatInt(id, 10)
	}
	u, _ := url.Parse(source.URL + "/query")
	q := u.Query()
	q.Set("objectIds", strings.Join(idStrings, ","))
	q.Set("outFields", strings.Join(source.OutFields, ","))
	q.Set("returnGeometry", "false")
	q.Set("f", "json")
	u.RawQuery = q.Encode()
	var payload arcGISFeatureResponse
	if err := l.getJSON(ctx, u.String(), &payload); err != nil {
		return nil, err
	}
	if payload.Error != nil {
		return nil, payload.Error.asError()
	}
	return payload.Features, nil
}

func (l ArcGISLoader) getJSON(ctx context.Context, endpoint string, into any) error {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, endpoint, nil)
	if err != nil {
		return err
	}
	req.Header.Set("Accept", "application/json")
	req.Header.Set("User-Agent", "baltimore-civic-insights/1.0 (student project)")
	resp, err := l.client.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		body, _ := io.ReadAll(io.LimitReader(resp.Body, 2048))
		return fmt.Errorf("HTTP %s: %s", resp.Status, strings.TrimSpace(string(body)))
	}
	decoder := json.NewDecoder(io.LimitReader(resp.Body, 100<<20))
	if err := decoder.Decode(into); err != nil {
		return fmt.Errorf("decode ArcGIS JSON: %w", err)
	}
	return nil
}

func (e *arcGISError) asError() error {
	if e == nil {
		return nil
	}
	return fmt.Errorf("ArcGIS API error %d: %s (%s)", e.Code, e.Message, strings.Join(e.Details, "; "))
}

func toInt64(v any) int64 {
	switch n := v.(type) {
	case float64:
		return int64(n)
	case int64:
		return n
	case int:
		return int64(n)
	case string:
		parsed, _ := strconv.ParseInt(n, 10, 64)
		return parsed
	default:
		return 0
	}
}

func writeRaw(path string, source Source, fs FeatureSet, offline bool) error {
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		return err
	}
	file, err := os.Create(path)
	if err != nil {
		return err
	}
	defer file.Close()
	wrapper := struct {
		Dataset   string    `json:"dataset"`
		SourceURL string    `json:"source_url"`
		FetchedAt time.Time `json:"fetched_at"`
		Offline   bool      `json:"offline_fixture"`
		FeatureSet
	}{Dataset: source.Title, SourceURL: source.URL, FetchedAt: time.Now().UTC(), Offline: offline, FeatureSet: fs}
	enc := json.NewEncoder(file)
	enc.SetIndent("", "  ")
	return enc.Encode(wrapper)
}

func readSavedRaw(path string) (FeatureSet, error) {
	file, err := os.Open(path)
	if err != nil {
		return FeatureSet{}, err
	}
	defer file.Close()
	var fs FeatureSet
	if err := json.NewDecoder(file).Decode(&fs); err != nil {
		return FeatureSet{}, err
	}
	return fs, nil
}
