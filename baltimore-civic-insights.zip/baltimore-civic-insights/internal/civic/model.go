package civic

import "time"

const (
	Source311   = "311_requests"
	SourceRehab = "vacant_building_rehabs"
)

type Feature struct {
	Attributes map[string]any `json:"attributes"`
}

type FeatureSet struct {
	Features []Feature `json:"features"`
}

type Source struct {
	Name        string
	Title       string
	URL         string
	OIDField    string
	OutFields   []string
	Fixture     string
	Description string
}

type Config struct {
	Offline     bool
	Limit       int
	Workers     int
	OutDir      string
	FixturesDir string
	Timeout     time.Duration
}

type ServiceRequest struct {
	ID              string
	RequestType     string
	CreatedAt       time.Time
	ClosedAt        time.Time
	Status          string
	Agency          string
	Neighborhood    string
	NeighborhoodKey string
	CouncilDistrict string
	DistrictKey     string
	PoliceDistrict  string
	ZipCode         string
	Address         string
}

type Rehab struct {
	ID              string
	Neighborhood    string
	NeighborhoodKey string
	CouncilDistrict string
	DistrictKey     string
	DateIssued      time.Time
	Address         string
	ProposedUse     string
}

type GroupRequestStats struct {
	Name               string
	Count              int
	Closed             int
	CloseHoursSum      float64
	CloseDurationCount int
}

type RequestStats struct {
	ByNeighborhood map[string]GroupRequestStats
	ByDistrict     map[string]GroupRequestStats
	Types          map[string]int
	Total          int
	Closed         int
	CloseHoursSum  float64
	CloseTimeCount int
}

type CountGroup struct {
	Name  string
	Count int
}

type RehabStats struct {
	ByNeighborhood map[string]CountGroup
	ByDistrict     map[string]CountGroup
	Total          int
}

type NeighborhoodRow struct {
	Neighborhood string
	Requests     int
	Closed       int
	CloseRate    float64
	AvgCloseDays float64
	RehabSites   int
}

type DistrictRow struct {
	CouncilDistrict       string
	Requests              int
	Closed                int
	CloseRate             float64
	AvgCloseDays          float64
	RehabSites            int
	RehabsPer1000Requests float64
}

type TypeRow struct {
	RequestType string
	Count       int
	Share       float64
}

type Report struct {
	GeneratedAt      time.Time
	Offline          bool
	Limit            int
	Workers          int
	RequestCount     int
	RehabCount       int
	ClosedCount      int
	OverallCloseRate float64
	AvgCloseDays     float64
	Neighborhoods    []NeighborhoodRow
	Districts        []DistrictRow
	Types            []TypeRow
	RequestSource    string
	RehabSource      string
}
