package civic

import (
	"context"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"sync"
	"time"
)

type sourceLoadResult struct {
	source Source
	data   FeatureSet
	err    error
}

func Run(ctx context.Context, cfg Config, output io.Writer) error {
	if cfg.Workers < 1 {
		return fmt.Errorf("worker count must be at least one")
	}
	if cfg.OutDir == "" {
		cfg.OutDir = "output"
	}
	if cfg.FixturesDir == "" {
		cfg.FixturesDir = "fixtures"
	}
	if cfg.Timeout <= 0 {
		cfg.Timeout = 45 * time.Second
	}
	if err := os.MkdirAll(filepath.Join(cfg.OutDir, "raw"), 0o755); err != nil {
		return fmt.Errorf("create output directory: %w", err)
	}

	sources := sourceCatalog()
	loader := NewLoader(cfg)
	fmt.Fprintf(output, "Loading %d Open Baltimore datasets concurrently (workers=%d, offline=%t)...\n", len(sources), cfg.Workers, cfg.Offline)
	results := make(chan sourceLoadResult, len(sources))
	var wg sync.WaitGroup
	for _, source := range sources {
		wg.Add(1)
		go func(source Source) {
			defer wg.Done()
			data, err := loader.Load(ctx, source, cfg)
			if err == nil {
				rawPath := filepath.Join(cfg.OutDir, "raw", source.Name+".json")
				err = writeRaw(rawPath, source, data, cfg.Offline)
			}
			results <- sourceLoadResult{source: source, data: data, err: err}
		}(source)
	}
	go func() { wg.Wait(); close(results) }()
	loaded := make(map[string]FeatureSet, len(sources))
	var loadErrs []error
	for result := range results {
		if result.err != nil {
			loadErrs = append(loadErrs, fmt.Errorf("%s: %w", result.source.Title, result.err))
			continue
		}
		loaded[result.source.Name] = result.data
		fmt.Fprintf(output, "  %-26s %d records\n", result.source.Name, len(result.data.Features))
	}
	if len(loadErrs) > 0 {
		return fmt.Errorf("dataset ingestion failed: %v", loadErrs)
	}

	// Parsing has its own bounded worker pool. Aggregators then operate in
	// parallel shards and the report joins independent keys concurrently.
	requests := parseRequests(loaded[Source311].Features, cfg.Workers)
	rehabs := parseRehabs(loaded[SourceRehab].Features, cfg.Workers)
	report := buildReport(requests, rehabs, cfg, sources)
	if err := writeOutputs(cfg.OutDir, report); err != nil {
		return fmt.Errorf("write reports: %w", err)
	}
	fmt.Fprintf(output, "Analysis complete: %d parsed 311 requests, %d rehab-location records, %d neighborhoods joined, %d council districts.\n", report.RequestCount, report.RehabCount, len(report.Neighborhoods), len(report.Districts))
	fmt.Fprintln(output, "Top neighborhood chart:")
	fmt.Fprint(output, chartNeighborhoods(report.Neighborhoods, 8))
	fmt.Fprintln(output, "Top request-type chart:")
	fmt.Fprint(output, chartTypes(report.Types, 8))
	fmt.Fprintf(output, "\nOutputs written to %s\n", cfg.OutDir)
	return nil
}
