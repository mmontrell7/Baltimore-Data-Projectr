package civic

// sourceCatalog centralizes the upstream schema and forms the source factory's
// registry. Keeping fields explicit avoids downloading unrelated personal or
// operational fields from the source services.
func sourceCatalog() []Source {
	return []Source{
		{
			Name: Source311, Title: "311 Customer Service Requests 2026",
			URL:       "https://services1.arcgis.com/UWYHeuuJISiGmgXx/ArcGIS/rest/services/311_Customer_Service_Requests_current/FeatureServer/0",
			OIDField:  "RowID",
			OutFields: []string{"RowID", "SRRecordID", "ServiceRequestNum", "SRType", "CreatedDate", "SRStatus", "CloseDate", "Agency", "Neighborhood", "CouncilDistrict", "PoliceDistrict", "ZipCode", "Address", "IsDeleted"},
			Fixture:   "311_requests.json", Description: "Current-year 311 requests; source says updated daily.",
		},
		{
			Name: SourceRehab, Title: "Vacant Building Rehabs",
			URL:       "https://services1.arcgis.com/UWYHeuuJISiGmgXx/arcgis/rest/services/Vacant_Building_Rehab/FeatureServer/0",
			OIDField:  "OBJECTID",
			OutFields: []string{"OBJECTID", "Neighborhood", "Council_District", "DateIssue", "DateIssued", "Address", "ProposedUse", "ExistingUse", "VBN"},
			Fixture:   "vacant_building_rehabs.json", Description: "Recorded vacant-building rehabilitation locations.",
		},
	}
}
