package civic

import (
	"fmt"
	"regexp"
	"strconv"
	"strings"
	"time"
)

var nonKeyChars = regexp.MustCompile(`[^a-z0-9]+`)
var districtNumber = regexp.MustCompile(`[0-9]+`)

func normalizeKey(s string) string {
	s = strings.ToLower(strings.TrimSpace(s))
	if s == "" || s == "null" || s == "none" || s == "n/a" || s == "unknown" {
		return ""
	}
	s = nonKeyChars.ReplaceAllString(s, " ")
	return strings.Join(strings.Fields(s), " ")
}

// normalizeDistrictKey accepts either bare numeric district values or labels
// such as "Council District 7" so source naming differences do not prevent a join.
func normalizeDistrictKey(s string) string {
	key := normalizeKey(s)
	if key == "" {
		return ""
	}
	numbers := districtNumber.FindAllString(key, -1)
	if len(numbers) == 1 {
		if number, err := strconv.Atoi(numbers[0]); err == nil {
			return strconv.Itoa(number)
		}
	}
	return key
}

func textValue(v any) string {
	if v == nil {
		return ""
	}
	switch value := v.(type) {
	case string:
		return strings.TrimSpace(value)
	case float64:
		return strconv.FormatFloat(value, 'f', -1, 64)
	case int64:
		return strconv.FormatInt(value, 10)
	case int:
		return strconv.Itoa(value)
	case bool:
		return strconv.FormatBool(value)
	default:
		return strings.TrimSpace(fmt.Sprint(v))
	}
}

func dateValue(v any) time.Time {
	switch value := v.(type) {
	case float64:
		if value <= 0 {
			return time.Time{}
		}
		return time.UnixMilli(int64(value)).UTC()
	case int64:
		if value <= 0 {
			return time.Time{}
		}
		return time.UnixMilli(value).UTC()
	case int:
		if value <= 0 {
			return time.Time{}
		}
		return time.UnixMilli(int64(value)).UTC()
	case string:
		s := strings.TrimSpace(value)
		if s == "" {
			return time.Time{}
		}
		if millis, err := strconv.ParseInt(s, 10, 64); err == nil && millis > 100000000000 {
			return time.UnixMilli(millis).UTC()
		}
		layouts := []string{time.RFC3339Nano, "2006-01-02T15:04:05", "2006-01-02", "1/2/2006", "01/02/2006", "2006"}
		for _, layout := range layouts {
			if parsed, err := time.Parse(layout, s); err == nil {
				return parsed.UTC()
			}
		}
	}
	return time.Time{}
}

type parsedRequest struct {
	value ServiceRequest
	ok    bool
}
type parsedRehab struct {
	value Rehab
	ok    bool
}

func parseRequests(features []Feature, workers int) []ServiceRequest {
	parsed := parallelMap(features, workers, func(feature Feature) parsedRequest {
		a := feature.Attributes
		if toInt64(a["IsDeleted"]) == 1 {
			return parsedRequest{}
		}
		id := textValue(a["SRRecordID"])
		if id == "" {
			id = textValue(a["ServiceRequestNum"])
		}
		if id == "" {
			id = textValue(a["RowID"])
		}
		kind := textValue(a["SRType"])
		if kind == "" {
			kind = "Unspecified"
		}
		neighborhood := textValue(a["Neighborhood"])
		district := textValue(a["CouncilDistrict"])
		return parsedRequest{value: ServiceRequest{
			ID: id, RequestType: kind, CreatedAt: dateValue(a["CreatedDate"]),
			ClosedAt: dateValue(a["CloseDate"]), Status: textValue(a["SRStatus"]),
			Agency: textValue(a["Agency"]), Neighborhood: neighborhood,
			NeighborhoodKey: normalizeKey(neighborhood), CouncilDistrict: district,
			DistrictKey: normalizeDistrictKey(district), PoliceDistrict: textValue(a["PoliceDistrict"]),
			ZipCode: textValue(a["ZipCode"]), Address: textValue(a["Address"]),
		}, ok: true}
	})
	out := make([]ServiceRequest, 0, len(parsed))
	for _, item := range parsed {
		if item.ok {
			out = append(out, item.value)
		}
	}
	return out
}

func parseRehabs(features []Feature, workers int) []Rehab {
	parsed := parallelMap(features, workers, func(feature Feature) parsedRehab {
		a := feature.Attributes
		id := textValue(a["OBJECTID"])
		if id == "" {
			id = textValue(a["BLOCKLOT"])
		}
		neighborhood := textValue(a["Neighborhood"])
		district := textValue(a["Council_District"])
		if district == "" {
			district = textValue(a["CouncilDistrict"])
		}
		return parsedRehab{value: Rehab{
			ID: id, Neighborhood: neighborhood, NeighborhoodKey: normalizeKey(neighborhood),
			CouncilDistrict: district, DistrictKey: normalizeDistrictKey(district),
			DateIssued: dateValue(a["DateIssue"]),
			Address:    textValue(a["Address"]), ProposedUse: textValue(a["ProposedUse"]),
		}, ok: true}
	})
	out := make([]Rehab, 0, len(parsed))
	for _, item := range parsed {
		if item.ok {
			out = append(out, item.value)
		}
	}
	return out
}

func parallelMap[T any, R any](items []T, workers int, fn func(T) R) []R {
	if workers < 1 {
		workers = 1
	}
	if workers > len(items) {
		workers = len(items)
	}
	if len(items) == 0 {
		return []R{}
	}
	type job struct {
		index int
		item  T
	}
	type result struct {
		index int
		value R
	}
	jobs := make(chan job)
	results := make(chan result, len(items))
	workerCount := workers
	for i := 0; i < workerCount; i++ {
		go func() {
			for j := range jobs {
				results <- result{index: j.index, value: fn(j.item)}
			}
		}()
	}
	go func() {
		for i, item := range items {
			jobs <- job{index: i, item: item}
		}
		close(jobs)
	}()
	out := make([]R, len(items))
	for i := 0; i < len(items); i++ {
		r := <-results
		out[r.index] = r.value
	}
	return out
}
