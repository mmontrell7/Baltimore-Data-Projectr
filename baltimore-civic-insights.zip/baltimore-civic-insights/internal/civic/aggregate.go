package civic

import (
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"
)

func closedStatus(status string, closeDate time.Time) bool {
	if !closeDate.IsZero() {
		return true
	}
	s := strings.ToLower(strings.TrimSpace(status))
	return strings.Contains(s, "closed") || strings.Contains(s, "resolved") || strings.Contains(s, "completed")
}

func addRequestGroup(groups map[string]GroupRequestStats, key, name string, request ServiceRequest) {
	if key == "" {
		return
	}
	group := groups[key]
	if group.Name == "" {
		group.Name = name
	}
	group.Count++
	if closedStatus(request.Status, request.ClosedAt) {
		group.Closed++
	}
	if !request.CreatedAt.IsZero() && !request.ClosedAt.IsZero() && !request.ClosedAt.Before(request.CreatedAt) {
		group.CloseHoursSum += request.ClosedAt.Sub(request.CreatedAt).Hours()
		group.CloseDurationCount++
	}
	groups[key] = group
}

func aggregateRequestsConcurrent(records []ServiceRequest, workers int) RequestStats {
	if workers < 1 {
		workers = 1
	}
	if workers > len(records) && len(records) > 0 {
		workers = len(records)
	}
	if len(records) == 0 {
		workers = 1
	}
	parts := make(chan RequestStats, workers)
	var wg sync.WaitGroup
	for shard := 0; shard < workers; shard++ {
		wg.Add(1)
		go func(shard int) {
			defer wg.Done()
			part := RequestStats{ByNeighborhood: map[string]GroupRequestStats{}, ByDistrict: map[string]GroupRequestStats{}, Types: map[string]int{}}
			for i := shard; i < len(records); i += workers {
				r := records[i]
				part.Total++
				if closedStatus(r.Status, r.ClosedAt) {
					part.Closed++
				}
				if !r.CreatedAt.IsZero() && !r.ClosedAt.IsZero() && !r.ClosedAt.Before(r.CreatedAt) {
					part.CloseHoursSum += r.ClosedAt.Sub(r.CreatedAt).Hours()
					part.CloseTimeCount++
				}
				part.Types[r.RequestType]++
				addRequestGroup(part.ByNeighborhood, r.NeighborhoodKey, r.Neighborhood, r)
				addRequestGroup(part.ByDistrict, r.DistrictKey, r.CouncilDistrict, r)
			}
			parts <- part
		}(shard)
	}
	go func() { wg.Wait(); close(parts) }()
	all := RequestStats{ByNeighborhood: map[string]GroupRequestStats{}, ByDistrict: map[string]GroupRequestStats{}, Types: map[string]int{}}
	for part := range parts {
		all.Total += part.Total
		all.Closed += part.Closed
		all.CloseHoursSum += part.CloseHoursSum
		all.CloseTimeCount += part.CloseTimeCount
		for key, value := range part.Types {
			all.Types[key] += value
		}
		mergeRequestGroups(all.ByNeighborhood, part.ByNeighborhood)
		mergeRequestGroups(all.ByDistrict, part.ByDistrict)
	}
	return all
}

func mergeRequestGroups(dst, src map[string]GroupRequestStats) {
	for key, value := range src {
		current := dst[key]
		if current.Name == "" {
			current.Name = value.Name
		}
		current.Count += value.Count
		current.Closed += value.Closed
		current.CloseHoursSum += value.CloseHoursSum
		current.CloseDurationCount += value.CloseDurationCount
		dst[key] = current
	}
}

func aggregateRehabsConcurrent(records []Rehab, workers int) RehabStats {
	if workers < 1 {
		workers = 1
	}
	if workers > len(records) && len(records) > 0 {
		workers = len(records)
	}
	if len(records) == 0 {
		workers = 1
	}
	type partStats struct {
		neighborhoods, districts map[string]CountGroup
		total                    int
	}
	parts := make(chan partStats, workers)
	var wg sync.WaitGroup
	for shard := 0; shard < workers; shard++ {
		wg.Add(1)
		go func(shard int) {
			defer wg.Done()
			part := partStats{neighborhoods: map[string]CountGroup{}, districts: map[string]CountGroup{}}
			for i := shard; i < len(records); i += workers {
				r := records[i]
				part.total++
				if r.NeighborhoodKey != "" {
					group := part.neighborhoods[r.NeighborhoodKey]
					if group.Name == "" {
						group.Name = r.Neighborhood
					}
					group.Count++
					part.neighborhoods[r.NeighborhoodKey] = group
				}
				if r.DistrictKey != "" {
					group := part.districts[r.DistrictKey]
					if group.Name == "" {
						group.Name = r.CouncilDistrict
					}
					group.Count++
					part.districts[r.DistrictKey] = group
				}
			}
			parts <- part
		}(shard)
	}
	go func() { wg.Wait(); close(parts) }()
	all := RehabStats{ByNeighborhood: map[string]CountGroup{}, ByDistrict: map[string]CountGroup{}}
	for part := range parts {
		all.Total += part.total
		mergeCountGroups(all.ByNeighborhood, part.neighborhoods)
		mergeCountGroups(all.ByDistrict, part.districts)
	}
	return all
}

func mergeCountGroups(dst, src map[string]CountGroup) {
	for key, value := range src {
		current := dst[key]
		if current.Name == "" {
			current.Name = value.Name
		}
		current.Count += value.Count
		dst[key] = current
	}
}

type namedKey struct{ key, name string }

func unionKeys[A any, B any](a map[string]A, b map[string]B, nameA func(A) string, nameB func(B) string) []namedKey {
	union := make(map[string]string, len(a)+len(b))
	for key, item := range a {
		union[key] = nameA(item)
	}
	for key, item := range b {
		if union[key] == "" {
			union[key] = nameB(item)
		}
	}
	keys := make([]namedKey, 0, len(union))
	for key, name := range union {
		keys = append(keys, namedKey{key: key, name: name})
	}
	sort.Slice(keys, func(i, j int) bool { return keys[i].name < keys[j].name })
	return keys
}

func buildReport(requests []ServiceRequest, rehabs []Rehab, cfg Config, sources []Source) Report {
	var requestStats RequestStats
	var rehabStats RehabStats
	var wg sync.WaitGroup
	wg.Add(2)
	go func() { defer wg.Done(); requestStats = aggregateRequestsConcurrent(requests, cfg.Workers) }()
	go func() { defer wg.Done(); rehabStats = aggregateRehabsConcurrent(rehabs, cfg.Workers) }()
	wg.Wait()

	neighborhoodKeys := unionKeys(requestStats.ByNeighborhood, rehabStats.ByNeighborhood,
		func(v GroupRequestStats) string { return v.Name }, func(v CountGroup) string { return v.Name })

	neighborhoodRows := parallelMap(neighborhoodKeys, cfg.Workers, func(k namedKey) NeighborhoodRow {
		r := requestStats.ByNeighborhood[k.key]
		v := rehabStats.ByNeighborhood[k.key]
		return NeighborhoodRow{Neighborhood: k.name, Requests: r.Count, Closed: r.Closed,
			CloseRate: rate(r.Closed, r.Count), AvgCloseDays: averageDays(r.CloseHoursSum, r.CloseDurationCount), RehabSites: v.Count}
	})
	districtKeys := unionKeys(requestStats.ByDistrict, rehabStats.ByDistrict,
		func(v GroupRequestStats) string { return v.Name }, func(v CountGroup) string { return v.Name })
	districtRows := parallelMap(districtKeys, cfg.Workers, func(k namedKey) DistrictRow {
		r := requestStats.ByDistrict[k.key]
		v := rehabStats.ByDistrict[k.key]
		rehabRatio := 0.0
		if r.Count > 0 {
			rehabRatio = float64(v.Count) * 1000 / float64(r.Count)
		}
		return DistrictRow{CouncilDistrict: k.name, Requests: r.Count, Closed: r.Closed,
			CloseRate: rate(r.Closed, r.Count), AvgCloseDays: averageDays(r.CloseHoursSum, r.CloseDurationCount),
			RehabSites: v.Count, RehabsPer1000Requests: rehabRatio}
	})
	// Stable sorting makes the report and CSV files reproducible for a given snapshot.
	sort.Slice(neighborhoodRows, func(i, j int) bool {
		if neighborhoodRows[i].Requests != neighborhoodRows[j].Requests {
			return neighborhoodRows[i].Requests > neighborhoodRows[j].Requests
		}
		if neighborhoodRows[i].RehabSites != neighborhoodRows[j].RehabSites {
			return neighborhoodRows[i].RehabSites > neighborhoodRows[j].RehabSites
		}
		return neighborhoodRows[i].Neighborhood < neighborhoodRows[j].Neighborhood
	})
	sort.Slice(districtRows, func(i, j int) bool {
		return districtLess(districtRows[i].CouncilDistrict, districtRows[j].CouncilDistrict)
	})

	typeRows := make([]TypeRow, 0, len(requestStats.Types))
	for name, count := range requestStats.Types {
		typeRows = append(typeRows, TypeRow{RequestType: name, Count: count, Share: rate(count, requestStats.Total)})
	}
	sort.Slice(typeRows, func(i, j int) bool {
		if typeRows[i].Count != typeRows[j].Count {
			return typeRows[i].Count > typeRows[j].Count
		}
		return typeRows[i].RequestType < typeRows[j].RequestType
	})

	var requestSource, rehabSource string
	for _, source := range sources {
		if source.Name == Source311 {
			requestSource = source.URL
		}
		if source.Name == SourceRehab {
			rehabSource = source.URL
		}
	}
	return Report{GeneratedAt: time.Now().UTC(), Offline: cfg.Offline, Limit: cfg.Limit, Workers: cfg.Workers,
		RequestCount: requestStats.Total, RehabCount: rehabStats.Total, ClosedCount: requestStats.Closed,
		OverallCloseRate: rate(requestStats.Closed, requestStats.Total), AvgCloseDays: averageDays(requestStats.CloseHoursSum, requestStats.CloseTimeCount),
		Neighborhoods: neighborhoodRows, Districts: districtRows, Types: typeRows, RequestSource: requestSource, RehabSource: rehabSource}
}

func rate(n, total int) float64 {
	if total == 0 {
		return 0
	}
	return float64(n) / float64(total) * 100
}

func averageDays(hours float64, count int) float64 {
	if count == 0 {
		return 0
	}
	return hours / float64(count) / 24
}

func districtLess(a, b string) bool {
	ai, aerr := strconv.Atoi(strings.TrimSpace(a))
	bi, berr := strconv.Atoi(strings.TrimSpace(b))
	if aerr == nil && berr == nil {
		return ai < bi
	}
	if aerr == nil {
		return true
	}
	if berr == nil {
		return false
	}
	return a < b
}
