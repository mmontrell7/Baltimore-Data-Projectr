# Baltimore Civic Insights

Generated: 2026-10-15T17:55:35Z

Data mode: **synthetic offline fixture data (not real city statistics)**

## Coverage and limitations

- 311 records analyzed: **12**
- Vacant-building rehab records analyzed: **10**
- Records marked closed/resolved/completed (or with a close date): **9 of 12 (75.0%)**
- Average close duration among records with valid creation and close dates: **2.00 days**
- Worker count: **3**; per-dataset record cap: **50000**

The 311 layer is for the current calendar year and is described by its publisher as updated daily. The Vacant Building Rehabs layer records rehabilitation locations and has an older published data-edit timestamp (June 30, 2023). These sources are not equally current. Rehabilitation-location counts are not a count of all vacant buildings, and cross-dataset co-occurrence is descriptive rather than evidence of causation. Blank/missing neighborhood and district labels are excluded from those geographic joins but remain in citywide totals.

Sources: [311 Customer Service Requests 2026](https://services1.arcgis.com/UWYHeuuJISiGmgXx/ArcGIS/rest/services/311_Customer_Service_Requests_current/FeatureServer/0) · [Vacant Building Rehabs](https://services1.arcgis.com/UWYHeuuJISiGmgXx/arcgis/rest/services/Vacant_Building_Rehab/FeatureServer/0) · [Open Baltimore portal](https://data.baltimorecity.gov/)

## Research question 1 — Which neighborhoods have the highest 311 workload?

Top neighborhoods by request count (current snapshot / records loaded).

| Neighborhood | 311 requests | Rehab locations recorded | Closed rate |
|---|---:|---:|---:|
| Downtown | 3 | 2 | 100.0% |
| Pigtown/Washington Village | 3 | 2 | 66.7% |
| Cherry Hill | 2 | 2 | 50.0% |
| Sandtown-Winchester | 2 | 1 | 100.0% |
| Curtis Bay | 1 | 1 | 100.0% |
| Hampden | 1 | 1 | 0.0% |

```text
Downtown                      3 ########################
Pigtown/Washington Vill…      3 ########################
Cherry Hill                   2 ################
Sandtown-Winchester           2 ################
Curtis Bay                    1 ########
Hampden                       1 ########
```

## Research question 2 — Which request types dominate service demand?

| Request type | Count | Share of loaded requests |
|---|---:|---:|
| Illegal Dumping | 4 | 33.3% |
| Pothole | 3 | 25.0% |
| Street Light Out | 2 | 16.7% |
| Water Leak | 2 | 16.7% |
| Tree Maintenance | 1 | 8.3% |

```text
Illegal Dumping               4 ########################
Pothole                       3 ##################
Street Light Out              2 ############
Water Leak                    2 ############
Tree Maintenance              1 ######
```

## Research question 3 — Which neighborhoods combine many 311 requests with recorded rehabilitation activity?

This is a joined descriptive view, not a risk score. The join key is a normalized neighborhood name (case and punctuation standardized). Rankings below are ordered by 311 request volume; the rehab count is shown alongside each count.

| Neighborhood | 311 requests | Rehab locations recorded |
|---|---:|---:|
| Downtown | 3 | 2 |
| Pigtown/Washington Village | 3 | 2 |
| Cherry Hill | 2 | 2 |
| Sandtown-Winchester | 2 | 1 |
| Curtis Bay | 1 | 1 |
| Hampden | 1 | 1 |

## Research question 4 — How does recorded rehabilitation activity compare with 311 volume by council district?

The ratio is recorded rehab locations per 1,000 loaded 311 requests. Low request counts can make this ratio volatile; it should be reviewed alongside the underlying counts.

| Council district | 311 requests | Rehab locations recorded | Rehabs / 1,000 requests |
|---|---:|---:|---:|
| 10 | 3 | 3 | 1000.00 |
| 14 | 1 | 1 | 1000.00 |
| 7 | 3 | 2 | 666.67 |
| 11 | 3 | 2 | 666.67 |
| 9 | 2 | 1 | 500.00 |
| 1 | 0 | 1 | N/A |

```text
District 10       3 ########################
District 14       1 ########
District 7        2 ################
District 11       2 ################
District 9        1 ########
District 1        1 ########
```

## Research question 5 — How do closure outcomes and times vary by council district?

Closure rate is the share with a close date or a status containing closed, resolved, or completed. Average close time uses only records with valid creation and close dates and non-negative duration. A zero in the duration column means no valid duration was available, not instantaneous closure.

| Council district | Requests | Closed / resolved | Closed rate | Avg. close days (valid dates) |
|---|---:|---:|---:|---:|
| 1 | 0 | 0 | 0.0% | 0.00 |
| 7 | 3 | 2 | 66.7% | 1.50 |
| 9 | 2 | 2 | 100.0% | 3.00 |
| 10 | 3 | 2 | 66.7% | 2.00 |
| 11 | 3 | 3 | 100.0% | 1.67 |
| 14 | 1 | 0 | 0.0% | 0.00 |

## Reproducibility

Raw input snapshots are in `raw/`. CSV files are machine-readable companion outputs. If running in offline mode, fixtures are synthetic and must not be reported as observed Baltimore data.
